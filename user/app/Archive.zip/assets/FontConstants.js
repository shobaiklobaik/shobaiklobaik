export const ETFonts = {
  bold: "Lato-Bold",
  black: "Lato-Black",
  regular: "Lato-Regular",
  light: "Lato-Light",
  hairline: "Lato-Hairline",
  satisfy : "Satisfy-Regular"
};
