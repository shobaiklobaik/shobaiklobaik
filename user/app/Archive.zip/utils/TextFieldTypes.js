export const TextFieldTypes = {
    email: "email",
    password: "password",
    phone: "phone",
    name: "name",
    accountNumber:"accountNumber",
}